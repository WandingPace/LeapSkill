---
name: wayfinder
description: "Map and navigate large, uncertain multi-session efforts through a shared graph of decision tickets. Use when facing complex greenfield projects or massive architectural migrations that exceed a single session — even if the user says \"map out this massive project\". 当中文用户要求“梳理这个大项目”“做项目路径规划”或“拆解大型迁移路线图”时也应使用。 Do NOT use for small, well-scoped features."
---

# Wayfinder：复杂项目路径规划

通过不断发展的决策工单图表和清晰的前沿发现，绘制、导航并逐步解决大型、不确定的多会话架构工作。

---

## 核心不变量

1. **先规划，后执行**：Wayfinder 工单解决决策、调查未知因素或验证原型，而不是直接执行任务。
2. **唯一权威地图工单**：维护一个标记为“wayfinder:map”的根跟踪工单，作为链接所有子决策工单的低分辨率索引。
3. **每个会话一张决策工单**：单个代理会话最多声明并解决一张决策工单（并行研究子代理除外）。
4. **边界声明协议**：会话必须在开始工作之前显式地将决策票分配给自己，以防止多代理冲突。
5. **迷雾逐层解除**：永远不要将模糊、遥远的工作预先分割成投机性的工单；将它们保留在“##尚未指定”中，直到边界到达它们。

---

## 架构和内容地图 (MOC)

```
[ Massive Uncertain Initiative ]
                │
                ▼
┌───────────────────────────────────────┐
│ 1. Chart Destination & Map Issue      │ ──► Issue `wayfinder:map`
│    (Notes, Fog sketches, Boundaries)  │
└──────────────────┬────────────────────┘
                   │
                   ▼
┌───────────────────────────────────────┐
│ 2. Frontier Decision Tickets          │ ──► Child issues (`research`, `prototype`, `grilling`, `task`)
│    (Unblocked, unclaimed questions)   │
└──────────────────┬────────────────────┘
                   │
                   ▼
┌───────────────────────────────────────┐
│ 3. Atomic Session Resolution          │ ──► Post resolution comment, close issue,
│    (Claim 1 ticket, settle decision)  │     update `Decisions so far`, graduate fog
└───────────────────────────────────────┘
```

|工单类型 |执行模式|目的|
|---|---|---|
| **研究** | AFK 子代理 |文档、API 发现、外部事实 |
| **原型** | HITL互动|一次性探索性代码（`skills/prototype/SKILL.md`）|
| **拷问** | HITL互动|苏格拉底决策蒸馏 (`skills/grilling/SKILL.md`) |
| **任务** | AFK 或 HITL |手动先决条件解锁（例如帐户设置、凭证配置）|

---

## 分步程序 (TWI)


- **行动**：广度优先地询问用户以定义目的地（最终规范、架构或迁移目标）并建立“wayfinder:map”根工单。
- **要点**：如果路线已经完全畅通无雾，则停止并直接前往“to-spec”。
- **为什么**：只有当起点和目的地之间存在大量未知决策时，才需要Wayfinder 开销。

### 第 2 步：制定 Frontier 子工单和依赖关系
- **行动**：创建指向明确的子工单以当前已被解锁的决策并连接本地阻塞关系。
- **要点**：将不明确的未来想法保留在地图的“## 尚未指定”部分。
- **内嵌清单**：
  - [ ] 使用清晰的目的地和注释创建的地图
  - [ ] 立即做出决定的问题已开票并贴上标签
  - [ ] 阻止跟踪器中的依赖关系
  - [ ] 研究工单发送给后台子代理

### 第 3 步：认领并解决单一前沿工单
- **行动**：将选定的前沿工单分配给自己，执行调查/拷问，并产生决策判决。
- **要点**：将决定作为问题的解决评论发布并关闭。
- **为什么**：立即关闭和评论使并发团队成员的边界保持干净和透明。

### 步骤 4：更新地图索引和解除迷雾
- **行动**：在地图问题上的“##到目前为止的决定”中添加一行摘要，并将新的可指定项目从“##尚未指定”升级到新工单中。
- **要点**：如果确定路径超出目标范围，请将其移至“## 超出范围”并关闭所有关联的工单。
- **为什么**：增量雾清除可以保持地图准确，而不会造成投机性膨胀。

---

## 反合理化护栏

|诱人的合理化|约束规则|工程原理 |
|---|---|---|
| *“我将在本次会话中解决 4 张工单。”* | **每个会话执行 1 张决策工单。** |批量处理多张工单会导致上下文耗尽和草率的决策记录。 |
| *“为所有未来阶段预先创建 20 张工单。”* | **将模糊工作保留在“尚未指定”中。** |预先划分迷雾会产生脆弱的工单，这些工单会因早期决策而失效。 |
| *“在 Wayfinder 过程中开始构建最终的功能代码。”* | **Wayfinder 产生决策，而不是可交付成果。** |在架构模糊的情况下过早实施会导致大规模重写。 |
